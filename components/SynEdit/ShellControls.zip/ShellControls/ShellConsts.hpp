// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Shellconsts.pas' rev: 20.00

#ifndef ShellconstsHPP
#define ShellconstsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Shellconsts
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _SShellDefaultNameStr;
#define Shellconsts_SShellDefaultNameStr System::LoadResourceString(&Shellconsts::_SShellDefaultNameStr)
extern PACKAGE System::ResourceString _SShellDefaultSizeStr;
#define Shellconsts_SShellDefaultSizeStr System::LoadResourceString(&Shellconsts::_SShellDefaultSizeStr)
extern PACKAGE System::ResourceString _SShellDefaultTypeStr;
#define Shellconsts_SShellDefaultTypeStr System::LoadResourceString(&Shellconsts::_SShellDefaultTypeStr)
extern PACKAGE System::ResourceString _SShellDefaultModifiedStr;
#define Shellconsts_SShellDefaultModifiedStr System::LoadResourceString(&Shellconsts::_SShellDefaultModifiedStr)
extern PACKAGE System::ResourceString _SShellNoDetails;
#define Shellconsts_SShellNoDetails System::LoadResourceString(&Shellconsts::_SShellNoDetails)
extern PACKAGE System::ResourceString _SCallLoadDetails;
#define Shellconsts_SCallLoadDetails System::LoadResourceString(&Shellconsts::_SCallLoadDetails)
extern PACKAGE System::ResourceString _SPalletePage;
#define Shellconsts_SPalletePage System::LoadResourceString(&Shellconsts::_SPalletePage)
extern PACKAGE System::ResourceString _SPropertyName;
#define Shellconsts_SPropertyName System::LoadResourceString(&Shellconsts::_SPropertyName)
extern PACKAGE System::ResourceString _SRenamedFailedError;
#define Shellconsts_SRenamedFailedError System::LoadResourceString(&Shellconsts::_SRenamedFailedError)
#define SRFDesktop L"rfDesktop"
#define SCmdVerbOpen L"open"
#define SCmdVerbRename L"rename"
#define SCmdVerbDelete L"delete"
#define SCmdVerbPaste L"paste"

}	/* namespace Shellconsts */
using namespace Shellconsts;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ShellconstsHPP
